package org.example.kombatfetchingback.handler;


import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Setter
@Getter
@Repository
@RequiredArgsConstructor
public class MyDataHandler implements DataHandler {
    private ConcurrentHashMap<String, Boolean> roomIsActive = new ConcurrentHashMap<>();
    @Override
    public String sendTestData() {

        return "Successfully created a room";
    }
    public MessageHolder initializeWebSocket(String id) {
        if(roomIsActive.containsKey(id)){
            return new MyMessageHolder(false,"Room already exists");
        }
        roomIsActive.put(id, true);
        IO.println(roomIsActive.get(id));
        IO.println(id);
        return new MyMessageHolder(true,"Successfully created a room");
    }

    public MessageHolder handleJoinRequest(String id) {

        if(roomIsActive.containsKey(id)){
            roomIsActive.remove(id);
            return new MyMessageHolder(true,"ws://localhost:8080/ws/" + id);
        }
        return new MyMessageHolder(false,"Room does not exists");
    }


}
