package org.example.kombatfetchingback.config;


import lombok.AllArgsConstructor;
import org.example.kombatfetchingback.repository.MyUserRepository;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectedEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

@Component
@AllArgsConstructor
public class WebsocketEventListener {
    private final MyUserRepository myUserRepository;
    private final SimpMessageSendingOperations messagingTemplate;
    @EventListener
    public void onConnect(SessionConnectedEvent event) {

        myUserRepository.increaseUserCount();
//        messagingTemplate.convertAndSend("/topic/user-number",myUserRepository.getUserCount());
        messagingTemplate.convertAndSend("/topic/user-number",myUserRepository.getUserCount());
    }
    @EventListener
    public void printUser(SessionConnectedEvent event) {
        IO.println("Someone joined");
//        IO.println(event.getUser());
        IO.println(event.toString());
    }
    @EventListener
    public void onDisconnect(SessionDisconnectEvent event) {
        myUserRepository.decreaseUserCount();
        messagingTemplate.convertAndSend("/topic/user-number",myUserRepository.getUserCount());
    }
}
