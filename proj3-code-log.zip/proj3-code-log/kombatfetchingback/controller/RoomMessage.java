package org.example.kombatfetchingback.controller;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoomMessage {
    private String roomId;
    private String content;

    // getters + setters
}