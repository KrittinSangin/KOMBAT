package org.example.kombatfetchingback.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
@RequiredArgsConstructor
public class RoomController {

    private final SimpMessagingTemplate messagingTemplate;

    @MessageMapping("/room.send")
    public void sendToRoom(@Payload RoomMessage message) {
        messagingTemplate.convertAndSend(
                "/topic/room/" + message.getRoomId(),
                message
        );
    }

    @MessageMapping("/config")
    public void sendToConfig(@Payload String message) {
        IO.println(message);
        messagingTemplate.convertAndSend(
                "/topic/config/",
                message
        );
    }

    @MessageMapping("/config/userOnline")
    public void sendOnline(@Payload String message) {
        IO.println(message);
        messagingTemplate.convertAndSend(
                "/topic/config/userOnline/",
                message
        );
    }


}